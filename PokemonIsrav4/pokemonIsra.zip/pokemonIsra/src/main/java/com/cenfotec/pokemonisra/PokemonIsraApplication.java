package com.cenfotec.pokemonisra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PokemonIsraApplication {

    public static void main(String[] args) {
        SpringApplication.run(PokemonIsraApplication.class, args);
    }

}
